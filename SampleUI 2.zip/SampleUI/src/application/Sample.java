package application;

import javax.swing.GroupLayout.Alignment;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

public class Sample extends BorderPane {
	
	private Rectangle 	standIn;
	private Button		takePicture;
	private Text		status;
	private TextField	fileName;
	private Text		title;
	
	public Sample() {
		
		title = new Text("Fire Cam");
		title.setFill(Color.DARKRED);
		title.setFont(new Font(30));
		title.setWrappingWidth(400);
		title.setTextAlignment(TextAlignment.CENTER);
		
		VBox capture = new VBox();
		standIn = new Rectangle(200, 200);
		standIn.setStroke(Color.DARKRED);
		standIn.setStrokeWidth(5);
		
		HBox captureButton = new HBox();
		status = new Text("Not Saved");
		status.setStyle("-fx-font-style: italic");
		takePicture = new Button("Take Picture");
		takePicture.setOnMouseClicked(e -> takePicture());
		
		captureButton.setAlignment(Pos.CENTER_RIGHT);
		captureButton.setSpacing(5);
		captureButton.getChildren().addAll(status, takePicture);
		capture.setSpacing(5);
		capture.getChildren().addAll(standIn, captureButton);
		
		
		setTop(title);
		setRight(capture);
		
		BorderPane.setMargin(capture, new Insets(25, 15, 15, 15));
	}

	private void takePicture() {
		status.setText("Saved");
		Thread.sleep(intervalInMills);
		TimeUnit.MILLISECONDS.sleep(intervalInMills);
	}
}
